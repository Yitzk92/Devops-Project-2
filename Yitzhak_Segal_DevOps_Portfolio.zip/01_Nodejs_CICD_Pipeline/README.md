# Node.js CI/CD Pipeline

This project demonstrates CI/CD using GitHub Actions, Docker, and AWS EC2.