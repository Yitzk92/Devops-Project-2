#!/bin/bash
scp docker-image user@ec2:/home/ubuntu/
ssh user@ec2 'docker run -d -p 80:80 my-node-app'